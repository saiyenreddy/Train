public class main {
    public static void main(String[] args) {
        int[] arrivals = new int[7];
        int[] departures = new int[7];
        arrivals[0]= 912;
        arrivals[1]= 922;
        arrivals[2]= 932;
        arrivals[3]= 92;
        arrivals[4]= 999;
        arrivals[5]= 12;
        arrivals[6]= 12;
        departures[0] = 1000;
        departures[1] = 1200;
        departures[2] = 3000;
        departures[3] = 94;
        departures[4] = 1000;
        departures[5] = 40;
        departures[6] = 50;
        amountoftracks(arrivals,departures);

    }

    public static void amountoftracks(int[] arrivals, int[] departures) { //O(N+N^2)
        int[][] combinedarray = sort(arrivals,departures);
        int max = 0;
        int numtracks = 0;
        for(int i = 0; i<combinedarray[0].length; i++){
            if(combinedarray[1][i]==-1){
                numtracks++;
            }
            if(numtracks>max){
                max=numtracks;
            }
            if(combinedarray[1][i]==1){
                numtracks--;
            }
        }
        System.out.println(max);
    }

    public static int[][] sort(int[] arrivals, int[] departures) { //O(N^2)
        int[][] combinedarray = new int[2][arrivals.length];
        int[][] singlearray = new int [2][arrivals.length*2];
        boolean checker = true;
        int holder;
        int arrivalnumber = 0;
        int departurenumber=0;
        while (checker == true) {
            checker = false;
            for (int i = 0; i < arrivals.length - 1; i++) {
                if (arrivals[i] > arrivals[i + 1]) {
                    holder = arrivals[i];
                    arrivals[i] = arrivals[i + 1];
                    arrivals[i + 1] = holder;
                    checker = true;
                    holder = departures[i];
                    departures[i] = departures[i + 1];
                    departures[i + 1] = holder;
                }
            }
        }
      for(int i =  0; i < arrivals.length-1;i++){
          combinedarray[0][i] = arrivals[i];
          combinedarray[1][i] = departures[i];
      }
        checker = true;
     for(int i =0; i < arrivals.length*2-1;i++){
         if(departurenumber==arrivals.length){
             singlearray[0][i] = combinedarray[0][arrivalnumber];
             arrivalnumber++;
             singlearray[1][i] = -1;
         }else {
             if(arrivalnumber==arrivals.length){
                 singlearray[0][i] = combinedarray[1][departurenumber];
                 departurenumber++;
                 singlearray[1][i] = 1;
             }else {
                 if (combinedarray[0][arrivalnumber] > combinedarray[1][departurenumber]) {
                     singlearray[0][i] = combinedarray[1][departurenumber];
                     departurenumber++;
                     singlearray[1][i] = 1;
                 } else {
                     singlearray[0][i] = combinedarray[0][arrivalnumber];
                     arrivalnumber++;
                     singlearray[1][i] = -1;
                 }
             }
         }
     }
     singlearray[1][singlearray[0].length-1]=1;
      return singlearray;
    }
}